import { Component } from '@angular/core';

@Component({
  selector: 'app-dps-component',
  standalone: false,
  templateUrl: './dps-component.html',
  styleUrl: './dps-component.css'
})
export class DpsComponent {

}
