export class Deposit {

  accountId!: string;    
  amount!: number;           
  transactionDate!: Date; 
  chequeNumber!: string;         
  depositDate!: Date;         
  transactionId?: string;     
  description?: string; 
  
}