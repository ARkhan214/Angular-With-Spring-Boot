import { User } from "./user.model";

export interface AuthResponse {

    token: string;
    message: string;

    // token:string;
    // user:User;

}