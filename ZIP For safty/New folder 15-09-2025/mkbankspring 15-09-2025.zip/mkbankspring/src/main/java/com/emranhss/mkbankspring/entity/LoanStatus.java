package com.emranhss.mkbankspring.entity;

public enum LoanStatus {
    PENDING,
    APPROVED,
    ACTIVE,
    REJECTED,
    CLOSED,
    DEFAULTED

}
