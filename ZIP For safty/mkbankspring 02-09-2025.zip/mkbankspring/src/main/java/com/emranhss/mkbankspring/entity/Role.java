package com.emranhss.mkbankspring.entity;

public enum Role {

    ADMIN,
    EMPLOYEE,
    USER
}
