package com.emranhss.mkbankspring.entity;

public enum LoanType {

    PERSONAL,
    HOME,
    CAR,
    EDUCATION,
    BUSINESS

}
