package com.emranhss.mkbankspring.entity;

public enum LoanStatus {
    PENDING,
    ACTIVE,
    CLOSED,
    DEFAULTED

}
