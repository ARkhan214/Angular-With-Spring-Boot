package com.emranhss.mkbankspring.entity;

public enum Position {
    MANAGER,
    CASHIER,
    ASSISTANT_MANAGER,
    OFFICER,
    TELLER,
    SENIOR_OFFICER,
    JUNIOR_OFFICER,
    ACCOUNTANT,
    INTERN
}
