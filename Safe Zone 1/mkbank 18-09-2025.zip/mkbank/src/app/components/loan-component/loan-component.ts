import { Component } from '@angular/core';

@Component({
  selector: 'app-loan-component',
  standalone: false,
  templateUrl: './loan-component.html',
  styleUrl: './loan-component.css'
})
export class LoanComponent {

}
