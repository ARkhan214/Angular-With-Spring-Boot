package com.emranhss.mkbankspring.entity;

public enum EmployeeStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED,
    RETIRED
}
