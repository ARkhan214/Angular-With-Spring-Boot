package com.emranhss.mkbankspring.entity;

public enum GLType {
    PENALTY,
    DPS_PAYMENT,
    DPS_INTEREST_PAYABLE,
    FD_CLOSED_PENALTY,
    ELECTRICITY_BILL_GL,
    GAS_BILL_GL,
    WATER_BILL_GL,
    INTERNET_BILL_GL,
    MOBILE_BILL_GL,
    CREDIT_CARD_BILL_GL
}
