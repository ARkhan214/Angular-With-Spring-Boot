package com.emranhss.mkbankspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MkBankSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
