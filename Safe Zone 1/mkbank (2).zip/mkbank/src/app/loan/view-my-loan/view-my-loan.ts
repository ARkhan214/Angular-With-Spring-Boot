import { Component } from '@angular/core';

@Component({
  selector: 'app-view-my-loan',
  standalone: false,
  templateUrl: './view-my-loan.html',
  styleUrl: './view-my-loan.css'
})
export class ViewMyLoan {

}
