package com.emranhss.mkbankspring.entity;

public enum FdStatus {

        ACTIVE,       // FD is currently running
        CLOSED,       // FD matured and closed
        WITHDRAWN     // FD withdrawn before maturity


}
