
export enum LoanType {
  PERSONAL = 'PERSONAL',
  HOME = 'HOME',
  EDUCATION = 'EDUCATION',
  VEHICLE = 'VEHICLE'
 
}
