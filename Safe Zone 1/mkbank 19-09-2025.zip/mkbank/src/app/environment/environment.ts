export const environment = {

production:false,
springUrl: 'http://localhost:8085/api',

}