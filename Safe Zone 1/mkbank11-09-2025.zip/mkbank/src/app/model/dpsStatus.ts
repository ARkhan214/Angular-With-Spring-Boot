export enum DpsStatus {
    ACTIVE = 'ACTIVE',
    CLOSED = 'CLOSED',
    DEFAULTED = 'DEFAULTED'
}