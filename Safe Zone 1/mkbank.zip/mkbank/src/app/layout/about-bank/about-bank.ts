import { Component } from '@angular/core';

@Component({
  selector: 'app-about-bank',
  standalone: false,
  templateUrl: './about-bank.html',
  styleUrl: './about-bank.css'
})
export class AboutBank {

}
