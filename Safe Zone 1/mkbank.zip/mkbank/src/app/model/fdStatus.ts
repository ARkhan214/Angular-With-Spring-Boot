// src/app/models/fd-status.enum.ts
export enum FdStatus {
  ACTIVE = 'ACTIVE',
  CLOSED = 'CLOSED',
  WITHDRAWN = 'WITHDRAWN',
  DEFAULTED = 'DEFAULTED'
}
