package com.emranhss.mkbankspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MkBankSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MkBankSpringApplication.class, args);
	}

}
