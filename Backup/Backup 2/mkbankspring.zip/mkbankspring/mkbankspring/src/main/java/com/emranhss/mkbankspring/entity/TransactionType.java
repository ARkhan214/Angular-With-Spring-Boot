package com.emranhss.mkbankspring.entity;

public enum TransactionType {

    INITIALBALANCE,
    DEPOSIT,
    WITHDRAW,
    FIXED_DEPOSIT,
    TRANSFER,
    RECEIVE

}
