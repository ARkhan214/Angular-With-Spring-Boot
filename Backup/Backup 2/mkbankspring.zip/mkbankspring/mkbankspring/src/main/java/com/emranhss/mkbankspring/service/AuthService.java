package com.emranhss.mkbankspring.service;

import com.emranhss.mkbankspring.entity.*;
import com.emranhss.mkbankspring.repository.UserRepository;
import jakarta.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

@Service
public class AuthService {


    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AccountService accountService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private TransactionService transactionService;

    @Value("src/main/resources/static/images")
    private String uploadDir;

    //Method for save,update or register (connected with UserResCon Method Number -1)
    public void saveOrUpdateUser(User user, MultipartFile imageFile) {
        if (imageFile != null && !imageFile.isEmpty()) {
            String fileName = saveImage(imageFile,user);
            user.setPhoto(fileName);
        }

        user.setRole(Role.ADMIN);
        userRepository.save(user);
        sendActivationEmail(user);
    }


    //method for find all user
    public List<User> findAll() {
        return userRepository.findAll();
    }
    //method for find user by id
    public User findById(Long id) {
        return userRepository.findById(id).get();
    }

    //method for find user by id or return null
    public User findUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }


    public void delete(User user) {
        userRepository.delete(user);
    }



    //Method for Send Email (connected with this saveOrUpdateUser methode)
    private void sendActivationEmail(User user) {
        String subject = "Welcome to Our Service – Confirm Your Registration";

        String mailText = "<!DOCTYPE html>"
                + "<html>"
                + "<head>"
                + "<style>"
                + "  body { font-family: Arial, sans-serif; line-height: 1.6; }"
                + "  .container { max-width: 600px; margin: auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 10px; }"
                + "  .header { background-color: #4CAF50; color: white; padding: 10px; text-align: center; border-radius: 10px 10px 0 0; }"
                + "  .content { padding: 20px; }"
                + "  .footer { font-size: 0.9em; color: #777; margin-top: 20px; text-align: center; }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "  <div class='container'>"
                + "    <div class='header'>"
                + "      <h2>Welcome to Our Platform</h2>"
                + "    </div>"
                + "    <div class='content'>"
                + "      <p>Dear " + user.getName() + ",</p>"
                + "      <p>Thank you for registering with us. We are excited to have you on board!</p>"
                + "      <p>Please confirm your email address to activate your account and get started.</p>"
                + "      <p>If you have any questions or need help, feel free to reach out to our support team.</p>"
                + "      <br>"
                + "      <p>Best regards,<br>The Support Team</p>"
                + "    </div>"
                + "    <div class='footer'>"
                + "      &copy; " + java.time.Year.now() + " MK Bank. All rights reserved."
                + "    </div>"
                + "  </div>"
                + "</body>"
                + "</html>";

        try {
            emailService.sendSimpleEmail(user.getEmail(), subject, mailText);
        } catch (MessagingException e) {
            throw new RuntimeException("Failed to send activation email", e);
        }
    }





//    private void sendTransactionEmail(Accounts accounts) {
//        Transaction transaction = new Transaction();
//        User user = new User();
//
//        String subject = "Transaction Confermation";
//
//        String mailText = "<!DOCTYPE html>"
//                + "<html>"
//                + "<head>"
//                + "<style>"
//                + "  body { font-family: Arial, sans-serif; line-height: 1.6; }"
//                + "  .container { max-width: 600px; margin: auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 10px; }"
//                + "  .header { background-color: #4CAF50; color: white; padding: 10px; text-align: center; border-radius: 10px 10px 0 0; }"
//                + "  .content { padding: 20px; }"
//                + "  .footer { font-size: 0.9em; color: #777; margin-top: 20px; text-align: center; }"
//                + "</style>"
//                + "</head>"
//                + "<body>"
//                + "  <div class='container'>"
//                + "    <div class='header'>"
//                + "      <h2>Welcome to Our Platform</h2>"
//                + "    </div>"
//                + "    <div class='content'>"
//                + "      <p>Dear " + accounts.getName() + ",</p>"
//                + "      <p>TK "+ transaction.getAmount()+" "+ transaction.getType()+" Succefull on "+ transaction.getTransactionTime()+"</p>"
//                + "      <br>"
//                + "      <p> Thanks for Stay with us</p>"
//                + "      <br>"
//                + "    </div>"
//                + "    <div class='footer'>"
//                + "      <p> Sincerely,</p>"
//                + "      <br>"
//                + "      <p>MK Bank Ltd.</p>"
//                + "    </div>"
//                + "  </div>"
//                + "</body>"
//                + "</html>";
//
//        try {
//            emailService.sendSimpleEmail(user.getEmail(), subject, mailText);
//        } catch (MessagingException e) {
//            throw new RuntimeException("Failed to send activation email", e);
//        }
//    }




    //Method for save image of file in User table
    public String saveImage(MultipartFile file, User user) {

        Path uploadPath = Paths.get(uploadDir + "/user");
        if (!Files.exists(uploadPath)) {
            try {
                Files.createDirectories(uploadPath);  // change here
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        String fileName = user.getName() + "_" + UUID.randomUUID().toString();
        try {
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(file.getInputStream(), filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return fileName;
    }





    //Method for save image of file in Account table
    public String saveImageForAccount(MultipartFile file, Accounts account) {
        Path uploadPath = Paths.get(uploadDir+"/account");
        if (!Files.exists(uploadPath)) {
            try {
                Files.createDirectory(uploadPath);

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        String accountName = account.getName();
        String fileName = accountName.trim().replaceAll("\\s+", "_") ;

        String savedFileName = fileName+"_"+UUID.randomUUID().toString();


        try {
            Path filePath = uploadPath.resolve(savedFileName);
            Files.copy(file.getInputStream(),filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return savedFileName;
    }


    // for account save or update or registration (connected with AccountResCon Method Number -1)
    public void registerAccount(User user, MultipartFile imageFile,Accounts accountData) {
        if (imageFile != null && !imageFile.isEmpty()) {

            String filename = saveImage(imageFile, user);
            String accountPhoto = saveImageForAccount(imageFile, accountData);
            accountData.setPhoto(accountPhoto);
            user.setPhoto(filename);

        }

        user.setRole(Role.USER);
        User savedUser = userRepository.save(user);


        accountData.setUser(savedUser);

        accountService.save(accountData);
        //for add initialDeposit ad first Transaction
        if (accountData.getBalance()>0){
            Transaction initialDeposit = new Transaction();
            initialDeposit.setAmount(accountData.getBalance());
            initialDeposit.setType(TransactionType.INITIALBALANCE);
            initialDeposit.setDescription("Initial deposit");
            transactionService.addTransaction(initialDeposit,accountData.getId());
        }

        sendActivationEmail(savedUser);
    }

}
