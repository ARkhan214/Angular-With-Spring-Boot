package com.emranhss.mkbankspring.service;



import org.springframework.stereotype.Service;
@Service
public class UserService {



}
