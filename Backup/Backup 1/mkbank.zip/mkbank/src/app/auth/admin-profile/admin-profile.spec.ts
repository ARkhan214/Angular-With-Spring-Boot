import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminProfile } from './admin-profile';

describe('AdminProfile', () => {
  let component: AdminProfile;
  let fixture: ComponentFixture<AdminProfile>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdminProfile]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminProfile);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
