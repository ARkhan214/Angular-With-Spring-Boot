export class User{

    id?:number;
    name!:string;
    email!:string;
    password!:string;
    phoneNumber!:string;
    dateOfBirth!:Date;
    role !:string;
    photo?: string;  
    
}