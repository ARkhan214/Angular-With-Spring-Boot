package com.emranhss.mkbankspring.entity;

public enum TransactionType {

    DEPOSIT,
    WITHDRAW,
    FIXED_DEPOSIT,
    TRANSFER,
    RECEIVE

}
